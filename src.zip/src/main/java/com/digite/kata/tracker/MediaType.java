package com.digite.kata.tracker;

public interface MediaType {

    public String generateWeatherAlert(String weatherConditions) ;
}
