package com.digite.kata.workflow;

public class SuperWorker implements LivingWorker{

    public void work() {
        //.... working much more
    }

    public void eat() {
        //.... eating in launch break
    }
}
