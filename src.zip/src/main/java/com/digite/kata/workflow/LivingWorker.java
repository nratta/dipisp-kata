package com.digite.kata.workflow;

public interface LivingWorker extends Worker {

    void eat();
}
