package com.digite.kata.workflow;

public class JuniorWorker implements LivingWorker{

    public void work() {
        // ....working
    }
    public void eat() {
        // ...... eating in launch break
    }
}
