package com.digite.kata.workflow;

public interface Worker {

    void work();
}
