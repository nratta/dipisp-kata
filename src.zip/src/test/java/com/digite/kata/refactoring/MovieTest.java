package com.digite.kata.refactoring;

import org.junit.Before;
import org.junit.Test;

public class MovieTest {

   /* @Before
    public void setUp()
    {

    }*/
    @Test
    public void testTitle()
    {
        Movie movie = new Movie("ABC",1);
    }
}
