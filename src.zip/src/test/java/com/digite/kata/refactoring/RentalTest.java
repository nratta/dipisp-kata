package com.digite.kata.refactoring;

import org.junit.Test;

public class RentalTest {

    @Test
    public void testGetMovie(){
        //

}
}
